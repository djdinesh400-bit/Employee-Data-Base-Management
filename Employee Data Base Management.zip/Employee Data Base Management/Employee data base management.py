# ---------- Employee Data Base Management System ----------

import csv
import tkinter as tk
from tkinter import ttk, messagebox

FILENAME = "employees.csv" 
FIELDNAMES = ["id", "name", "department", "role", "salary"]

# ---------- CSV Load & Save ----------
def load_employees(): #defining the function
    try: #try and expect methond, using this because if ang error happends the program will not crash)
        with open(FILENAME, "r", encoding="utf-8") as f: #open the file, read it & utf-8 allows python to read special german characters
            reader = csv.DictReader(f) #reads each row of the file and converst it into a dictionary 
            employees = list(reader) #converting all EE row details into list of dictionary 

            # Fix salary field
            for emp in employees: #goes though each EE one by one
                try:
                    emp["salary"] = float(emp["salary"]) #converting salary into float
                except:
                    emp["salary"] = 0.0 #if the input is empty or text, returns 0.0 and doesn't crash 
            return employees #return the final list
    except FileNotFoundError: #helps not to crash and retunrs empty list 
        return [] #if file not available, gives back the empty list

def save_employees(employees): #saves all EE in employee file
    with open(FILENAME, "w", newline="", encoding="utf-8") as f: #when opening the file, overwrite the file "w", prevent from extrablanks""
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)   #DictWriter knows these column names, so it can write the correct data into each column.
        writer.writeheader() #write the top row
        for emp in employees: #goes through EE dictionary line by line, row wise
            writer.writerow({  #to write a EE details into one row of the table in cvs file , below are the EE details
                "id": emp["id"],
                "name": emp["name"],
                "department": emp["department"],
                "role": emp["role"],
                "salary": emp["salary"],
            })

# ---------- GUI App ----------
def run_gui():
    root = tk.Tk() #creating the main window of the app
    root.title("Employee Report Management System") #naming the window title

    employees = load_employees() #loading the EE data from "Employees"

    # Input variables  - #***if i need to receive a input in calculaion or number, receive the input in fload EG :- float(tk.StringVar()) ***
    name_var = tk.StringVar() #to receive input creating a text container with "tk.StringVar" and storing the input in the variable "name_var"
    dept_var = tk.StringVar() #to receive input creating a text container with "tk.StringVar" and storing the input in the variable "dept_var"
    role_var = tk.StringVar() #to receive input creating a text container with "tk.StringVar" and storing the input in the variable "role_var"
    salary_var = tk.StringVar() #to receive input creating a text container with "tk.StringVar" and storing the input in the variable "salary_var"

    # ---------- Layout ----------
    tk.Label(root, text="Name").grid(row=0, column=0, padx=5, pady=5, sticky="w")
    tk.Entry(root, textvariable=name_var).grid(row=0, column=1, padx=5, pady=5)

    tk.Label(root, text="Department").grid(row=1, column=0, padx=5, pady=5, sticky="w")
    tk.Entry(root, textvariable=dept_var).grid(row=1, column=1, padx=5, pady=5)

    tk.Label(root, text="Role").grid(row=2, column=0, padx=5, pady=5, sticky="w")
    tk.Entry(root, textvariable=role_var).grid(row=2, column=1, padx=5, pady=5)

    tk.Label(root, text="Salary").grid(row=3, column=0, padx=5, pady=5, sticky="w")
    tk.Entry(root, textvariable=salary_var).grid(row=3, column=1, padx=5, pady=5)

    # Table
    tree = ttk.Treeview(root, columns=FIELDNAMES, show="headings", height=8)
    for col in FIELDNAMES:
        tree.heading(col, text=col.upper())
        tree.column(col, width=100)

    tree.grid(row=6, column=0, columnspan=2, padx=5, pady=10)

    # ---------- functions ----------
    def clear_fields(): # this fuction clear input boxes   
        name_var.set("") #clear the input
        dept_var.set("") #clear the input
        role_var.set("") #clear the input
        salary_var.set("") #clear the input
        tree.selection_remove(tree.selection()) #unselect the fields which is already selected, when clearing the input and its ready to use next

    def refresh_table():
        tree.delete(*tree.get_children()) #Deletes all rows from the table (tree) , (*) - unpack all row ID's, so they can be deleted at once  
        for emp in employees: #goes throught all the rows one by one 
            tree.insert(  #inters the EE data one by one in rows from the Employees. EG: Clear the TV screen -> read notes again -> show fresh data on TV
                "", # It tells Tkinter to put this row at the top level of the table
                tk.END, #add the row at the bottom
                values=( #EE data in row
                    emp["id"],
                    emp["name"],
                    emp["department"],
                    emp["role"],
                    emp["salary"],
                ),
            )

    # ---------- Add ----------
    def add_employee(): #adding new EE to the table(tree), take input from the user
        name = name_var.get().strip() #name_var -> text box for name ,,,, .get() -> read what the user typed ,,,  .strip() -> remove extra spaces
        dept = dept_var.get().strip()
        role = role_var.get().strip()
        salary_text = salary_var.get().strip()

        if not name or not dept or not role or not salary_text:
            messagebox.showerror("Error", "Please fill all fields.")
            return

        try:
            salary = float(salary_text)
        except ValueError:
            messagebox.showerror("Error", "Salary must be a number.")
            return

        emp_id = str(len(employees) + 1) #len(employees) = Means how many employees are there + 1

        emp = {
            "id": emp_id,
            "name": name,
            "department": dept,
            "role": role,
            "salary": salary,
        }

        employees.append(emp)
        save_employees(employees)
        refresh_table()
        clear_fields()
        messagebox.showinfo("Success", "Employee added successfully.")

    # ---------- Row select (load data to fields) ----------
    def on_row_select(event): #When you click a row in the table, this function puts that row's data into the input boxes.
        selected = tree.selection()
        if not selected: 
            return
        values = tree.item(selected[0], "values") #selected[0] = Go to the selected row , Get all column values from that row ,,,, Store them in values
        # values: (id, name, department, role, salary)
        name_var.set(values[1]) 
        dept_var.set(values[2])
        role_var.set(values[3])
        salary_var.set(values[4])

    # ---------- Update ----------
    def update_employee(): #update an existing employee
        selected = tree.selection() #select the row 
        if not selected:
            messagebox.showerror("Error", "Please select an employee to update.")
            return

        name = name_var.get().strip() #name_var -> text box for name ,,,, .get() -> read what the user typed ,,,  .strip() -> remove extra spaces
        dept = dept_var.get().strip()
        role = role_var.get().strip()
        salary_text = salary_var.get().strip()

        if not name or not dept or not role or not salary_text:
            messagebox.showerror("Error", "Please fill all fields.")
            return

        try:
            salary = float(salary_text)
        except ValueError:
            messagebox.showerror("Error", "Salary must be a number.")
            return

        values = tree.item(selected[0], "values") #selected[0] = Go to the selected row , Get all column values from that row ,,,, Store them in values
        emp_id = values[0]

        # Find and update the matching employee
        for emp in employees:
            if str(emp["id"]) == str(emp_id):
                emp["name"] = name
                emp["department"] = dept
                emp["role"] = role
                emp["salary"] = salary
                break
        else:
            messagebox.showerror("Error", "Employee not found.")
            return

        save_employees(employees)
        refresh_table()
        clear_fields()
        messagebox.showinfo("Success", "Employee updated successfully.")
        

    # ---------- Delete ----------
    def delete_employee(): #function defines the EE deletion
        selected = tree.selection() #if selected based on tree selection
        if not selected:
            messagebox.showerror("Error", "Please select an employee to delete.")
            return

        values = tree.item(selected[0], "values")
        emp_id = values[0]

        for emp in employees:
            if str(emp["id"]) == str(emp_id):
                employees.remove(emp)
                break

        save_employees(employees)
        refresh_table()
        clear_fields()
        messagebox.showinfo("Success", "Employee deleted successfully.")

    # ---------- Export ----------
    def export_to_csv(): #export function to csv file
        from tkinter import filedialog #importing fieldialong from tkinter 
        file_path = filedialog.asksaveasfilename(defaultextension=".csv") #assigning filedpath for csv file
        if file_path:
            save_employees(employees)
            import shutil #using import shutil to export
            shutil.copy(FILENAME, file_path)
            messagebox.showinfo("Success", "Data exported successfully!")

    tk.Button(root, text="Add Employee", command=add_employee).grid(
        row=4, column=0, padx=5, pady=5, sticky="we"
    )
    tk.Button(root, text="Update Employee", command=update_employee).grid(
        row=4, column=1, padx=5, pady=5, sticky="we"
    )
    tk.Button(root, text="Delete Employee", command=delete_employee).grid(
        row=5, column=0, padx=5, pady=5, sticky="we"
    )
    tk.Button(root, text="Export to CSV", command=export_to_csv).grid(
        row=5, column=1, padx=5, pady=5, sticky="we"
    )

    tree.bind("<<TreeviewSelect>>", on_row_select)

    refresh_table()
    root.mainloop()

# ---------- Main ----------
if __name__ == "__main__": #name of the file is "main" if it is main, then runs the APP
    run_gui() #runs the APP
