# Employee Data Base Management System

A simple desktop application for managing employee records using Python's Tkinter GUI framework and CSV file storage.

## Features

- **Add Employee** - Create new employee records with ID, name, department, role, and salary
- **Update Employee** - Modify existing employee information
- **Delete Employee** - Remove employee records from the database
- **Export to CSV** - Save employee data to a custom location
- **Data Persistence** - All changes are automatically saved to `employees.csv`

## Requirements

- Python 3.x
- tkinter (usually comes pre-installed with Python)
- csv module (built-in)

## Usage

### Running the Application

```bash
python employee_management.py
```

### Adding an Employee

1. Fill in all fields: Name, Department, Role, and Salary
2. Click the "Add Employee" button
3. The new employee will appear in the table below

### Updating an Employee

1. Click on an employee row in the table to select it
2. The employee's information will populate the input fields
3. Modify the desired fields
4. Click "Update Employee" to save changes

### Deleting an Employee

1. Click on an employee row in the table to select it
2. Click "Delete Employee"
3. Confirm the deletion

### Exporting Data

1. Click "Export to CSV"
2. Choose a location and filename
3. The current employee data will be saved to your chosen location

## File Structure

```
.
├── employee_management.py    # Main application file
└── employees.csv             # Employee database (auto-generated)
```

## Data Format

The `employees.csv` file contains the following columns:

- **id** - Unique employee identifier (auto-generated)
- **name** - Employee name
- **department** - Department name
- **role** - Job role/position
- **salary** - Employee salary (numeric)

## Notes

- Employee IDs are auto-generated based on the total count of employees
- The application handles missing or corrupted salary data by defaulting to 0.0
- UTF-8 encoding is used to support special characters (e.g., German characters)
- If `employees.csv` doesn't exist, the application will create it automatically

## Error Handling

- Empty fields are not allowed when adding or updating employees
- Salary must be a valid number
- Invalid CSV data is handled gracefully without crashing the application

## Future Enhancements

Potential improvements for future versions:

- Search and filter functionality
- Sorting by columns
- Input validation for department and role
- User authentication
- Database integration (SQLite, PostgreSQL)
- Reports and analytics
- Bulk import from external CSV files

